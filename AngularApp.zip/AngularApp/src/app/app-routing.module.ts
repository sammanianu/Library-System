import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { HomePanelComponent } from './home-panel/home-panel.component';
import { BookComponent } from './book/book.component';
import { SuggestComponent } from './suggest/suggest.component';
import { SuggestListComponent } from './suggest-list/suggest-list.component';
import { BookViewComponent } from './book-view/book-view.component';
import { EmployeeComponent } from './employee/employee.component';
import { TestComponent } from './test/test.component';

const routes: Routes = [
	{
		path: '',
		component: HomeComponent
	},
	{
		path: 'register',
		component: RegisterComponent
  	},
	{
		path: 'homePanel',
		component: HomePanelComponent
	},
	{
		path: 'book',
		component: BookComponent
	},
	{
		path: 'suggest',
		component: SuggestComponent
	},
	{
		path: 'bookView',
		component: BookViewComponent
	},
	{
		path: 'employee',
		component: EmployeeComponent
	},
	{
		path: 'suggestList',
		component: SuggestListComponent
	},
	{
		path: 'test',
		component: TestComponent
	},
	{
		path: 'registerList',
		component: RegisterListComponent
	}
];   

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
