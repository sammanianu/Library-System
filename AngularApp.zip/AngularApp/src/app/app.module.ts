import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AppRoutingModule } from './/app-routing.module';
import { RegisterComponent } from './register/register.component';
import { HomePanelComponent } from './home-panel/home-panel.component';
import { BookComponent } from './book/book.component';
import { SuggestComponent } from './suggest/suggest.component';
import { HomePanel1Component } from './home-panel1/home-panel1.component';
import { BookViewComponent } from './book-view/book-view.component';
import { SuggestListComponent } from './suggest-list/suggest-list.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { LoginComponent } from './login/login.component';
import { EmployeeComponent } from './employee/employee.component';
import { TestComponent } from './test/test.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegisterComponent,
    HomePanelComponent,
    BookComponent,
    SuggestComponent,
    HomePanel1Component,
    BookViewComponent,
    SuggestListComponent,
    RegisterListComponent,
    LoginComponent,
    EmployeeComponent,
    TestComponent
        ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
