import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { BookService } from '../shared/book.service';
import { Book } from '../shared/book.model';

import { LoginService } from '../shared/login.service';

declare var M: any;

@Component({
  selector: 'app-book-view',
  templateUrl: './book-view.component.html',
  styleUrls: ['./book-view.component.css'],
  providers: [BookService, LoginService]
})
export class BookViewComponent implements OnInit {
	modalBook:any
	public valueReadOut:string
	constructor(private bookService: BookService, public loginService: LoginService) { }
	

	
  ngOnInit() {
  	this.resetForm();
		this.refreshBookList();
  }

	reserve(){
    this.bookService.putBook(this.modalBook).subscribe((res) => {
			this.modalBook.availability = this.modalBook.availability-1;
			this.updateReserveList(); 
		});
	}

	updateReserveList(){

	}
	
  resetForm(form?: NgForm){
	  if(form)
  		form.reset();
  	this.bookService.selectedBook = {
  		_id: "",
  		isbn: "",
  		title: "",
  		author: "",
      publisher: "",
      category: "",
			language: "",
			summary: "",
			image: "",
      availability: null,
		}
		
  }

  onSubmit(form:NgForm){
	if(form.value._id  ==""){
		this.bookService.postBook(form.value).subscribe((res) => {
			this.resetForm(form);
			this.refreshBookList();
			M.toast({html: 'Saved successfully', classes: 'rounded'});
		});
	}
	else{
		this.bookService.putBook(form.value).subscribe((res) => {
			this.resetForm(form);
			this.refreshBookList();
			M.toast({html: 'Updated successfully', classes: 'rounded'});
		});
	}
  }

  refreshBookList(){
  	this.bookService.getBookList().subscribe((res) =>{
  		this.bookService.books = res as Book[];
  	});
  }

  onEdit(book: Book){
	this.bookService.selectedBook = book;
  }

  onDelete(_id: string, form: NgForm){
	  if (confirm('Are you sure to delete this record?') == true){
		this.bookService.deleteBook(_id).subscribe((res) => {
			this.refreshBookList();
			this.resetForm(form);
			M.toast({ html: 'Deleted successfully', classes:'rounded'});
		});
	  }
	}
	
	setModalData(event){
		this.modalBook = this.bookService.books[event.target.id]
		this.valueReadOut = this.loginService.gv;
		/*console.log(this.modalBook)*/
	}
}





















