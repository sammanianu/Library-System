import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-panel',
  templateUrl: './home-panel.component.html',
  styleUrls: ['./home-panel.component.css']
})
export class HomePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
