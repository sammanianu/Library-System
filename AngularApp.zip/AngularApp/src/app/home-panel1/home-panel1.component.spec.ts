import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePanel1Component } from './home-panel1.component';

describe('HomePanel1Component', () => {
  let component: HomePanel1Component;
  let fixture: ComponentFixture<HomePanel1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomePanel1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePanel1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
