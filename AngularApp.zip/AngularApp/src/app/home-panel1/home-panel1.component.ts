import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-panel1',
  templateUrl: './home-panel1.component.html',
  styleUrls: ['./home-panel1.component.css']
})
export class HomePanel1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
