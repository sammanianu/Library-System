import { Component, OnInit } from '@angular/core';
import {enableProdMode} from '@angular/core';

enableProdMode();

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  itemCount: number;
  btnText: string = "Add an item";
  goalText: string = 'My first life goal';
  goals = [];	

  constructor() { }

  ngOnInit() {
  	this.itemCount = this.goals.length;
  }

  addItem(){
	  this.goals.push(this.goalText);
	  this.goalText = '';
	  this.itemCount = this.goals.length;
  }

  removeItem(i){
  	this.goals.splice(i,1);
  }
}
