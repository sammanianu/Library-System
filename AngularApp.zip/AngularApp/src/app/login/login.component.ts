import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { LoginService } from '../shared/login.service';
import { Login } from '../shared/login.model';
import { HttpClient } from 'selenium-webdriver/http';

declare var M: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]

})
export class LoginComponent implements OnInit {

   
  public usernameLogin: string;
  public passwordLogin: string;

  constructor(private loginService: LoginService) { }

  ngOnInit() {
  }

  test:any = false;
  
  logMeIn(form:NgForm){

    this.loginService.postLogin(form.value).subscribe((res) => {
      
      if (res['success'] === true){
        this.test = true;
        M.toast({html: 'Login successfully', classes: 'rounded'});
      }else{
        M.toast({html: 'not Login successfully', classes: 'rounded'});
      }
    
    });


    /*login:Login*/
    /*this.test = true;
    this.usernameLogin =  'Sammani Anuththara';
    this.passwordLogin = this.loginService.gv;*/
	}
	
	logMeOut(){
		this.test = false;
	}

}
