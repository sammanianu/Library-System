import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { RegisterService } from '../shared/register.service';
import { Register } from '../shared/register.model';

declare var M: any;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [RegisterService]
})
export class RegisterComponent implements OnInit {
	modalRegister:any
  	constructor(private registerService: RegisterService) { }
	
  ngOnInit() {
  	this.resetForm();
  	this.refreshRegisterList();
  }

  resetForm(form?: NgForm){
	  if(form)
  		form.reset();
  	this.registerService.selectedRegister = {
  		_id: "",
  		username: "",
  		email: "",
			password: "",
			registrationNo: "",
			year:"",
			mobile:"",
			address: ""
  	}
  }

  onSubmit(form:NgForm){
	if(form.value._id  ==""){
		this.registerService.postRegister(form.value).subscribe((res) => {
			this.resetForm(form);
			this.refreshRegisterList();
			M.toast({html: 'Saved successfully', classes: 'rounded'});
		});
	}
	else{
		this.registerService.putRegister(form.value).subscribe((res) => {
			this.resetForm(form);
			this.refreshRegisterList();
			M.toast({html: 'Updated successfully', classes: 'rounded'});
		});
	}
  }

  refreshRegisterList(){
  	this.registerService.getRegisterList().subscribe((res) =>{
  		this.registerService.registers = res as Register[];
  	});
  }

  onEdit(reg: Register){
	this.registerService.selectedRegister = reg;
  }

  onDelete(_id: string, form: NgForm){
	  if (confirm('Are you sure to delete this record?') == true){
		this.registerService.deleteRegister(_id).subscribe((res) => {
			this.refreshRegisterList();
			this.resetForm(form);
			M.toast({ html: 'Deleted successfully', classes:'rounded'});
		});
	  }
	}
	
	setModalData(event){
		this.modalRegister = this.registerService.registers[event.target.id]
		/*console.log(this.modalBook)*/
	}

}





















