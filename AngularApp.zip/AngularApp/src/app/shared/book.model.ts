export class Book {
	_id: string;
	isbn: string;
	title: string;
	author: string;
	publisher: string;
    category: string;
	language: string;
	summary: string;
	image: string;
    availability: number;

}
