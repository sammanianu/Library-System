import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import { Book } from './book.model';

@Injectable()
export class BookService {
	selectedBook: Book;
	books: Book[];
	readonly baseURL = 'http://localhost:8080/books';
	
  	constructor(private http: HttpClient) { }

  	postBook(book: Book){
  		return this.http.post(this.baseURL, book);
  	}

  	getBookList(){
  		return this.http.get(this.baseURL);
	  }
	  
	putBook(book: Book){
		return this.http.put(this.baseURL + '/' + book._id, book);
	}

	deleteBook(_id: string){
		return this.http.delete(this.baseURL + `/${_id}`);
	}
}
