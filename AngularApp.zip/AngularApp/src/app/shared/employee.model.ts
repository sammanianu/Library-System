export class Employee {
    _id: string;
	name: string;
	email: string;
	mobile: string;
	position: string;
	salary: number;
}
