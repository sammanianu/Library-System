export class Login {
	_id: string;
	email: string;
	password: string;	
}
