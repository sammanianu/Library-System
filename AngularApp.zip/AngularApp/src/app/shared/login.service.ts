import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import { Login } from './login.model';

@Injectable()
export class LoginService {
	selectedLogin: Login;
	logins: Login[];
	readonly baseURL = 'http://localhost:8080/logins';
	
	  constructor(private http: HttpClient) { }
	  
	  postLogin(log: Login){
		  console.log(log);
		return this.http.post(this.baseURL, log);
	}

	public gv = "sam";
	getLoginList(){
		return this.http.get(this.baseURL);
	}
	
  putLogin(reg: Login){
	
	return this.http.put(this.baseURL + '/' + reg._id, reg);
  }

  deleteLogin(_id: string){
	return this.http.delete(this.baseURL + `/${_id}`);
  }

}


  	
  	
