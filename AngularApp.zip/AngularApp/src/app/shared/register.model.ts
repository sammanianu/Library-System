export class Register {
    _id: string;
	username: string;
	email: string;
	password: string;
	registrationNo: string;
	year:string;
	mobile:string;
	address: string;
	
}
