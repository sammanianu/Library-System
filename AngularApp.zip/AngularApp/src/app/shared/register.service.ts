import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import { Register } from './register.model';

@Injectable()
export class RegisterService {
	selectedRegister: Register;
	registers: Register[];
	readonly baseURL = 'http://localhost:8080/registers';
	
  	constructor(private http: HttpClient) { }

  	postRegister(reg: Register){
  		return this.http.post(this.baseURL, reg);
  	}

  	getRegisterList(){
  		return this.http.get(this.baseURL);
	  }
	  
    putRegister(reg: Register){
      
      return this.http.put(this.baseURL + '/' + reg._id, reg);
    }
  
    deleteRegister(_id: string){
      return this.http.delete(this.baseURL + `/${_id}`);
    }
}
