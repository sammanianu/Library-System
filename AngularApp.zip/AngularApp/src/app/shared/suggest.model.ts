export class Suggest {
    _id: string;
	title: string;
	author: string;
}
