import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import { Suggest } from './suggest.model';

@Injectable()
export class SuggestService {
	selectedSuggest: Suggest;
	suggests: Suggest[];
	readonly baseURL = 'http://localhost:8080/suggests';
	
  	constructor(private http: HttpClient) { }

  	postSuggest(sug: Suggest){
  		return this.http.post(this.baseURL, sug);
  	}

  	getSuggestList(){
  		return this.http.get(this.baseURL);
	  }
	  
	putSuggest(sug: Suggest){
		console.log("ID is " + sug._id)
		console.log(this.baseURL + "/" + sug._id, sug)
		return this.http.put(this.baseURL + '/' + sug._id, sug);
	}

	deleteSuggest(_id: string){
		return this.http.delete(this.baseURL + `/${_id}`);
	}
}
