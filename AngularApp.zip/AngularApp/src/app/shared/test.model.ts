export class Test {
    _id: string;
	email: string;
	password: string;
}
