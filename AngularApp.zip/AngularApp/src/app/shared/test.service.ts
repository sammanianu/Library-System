import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import { Test } from './test.model';

@Injectable()
export class TestService {
	selectedTest: Test;
	tests: Test[];
	readonly baseURL = 'http://localhost:8080/tests';
	
  	constructor(private http: HttpClient) { }

  	postTest(reg: Test){
  		return this.http.post(this.baseURL, reg);
  	}

  	getTestList(){
  		return this.http.get(this.baseURL);
	  }
	  
    putTest(reg: Test){
      
      return this.http.put(this.baseURL + '/' + reg._id, reg);
    }
  
    deleteTest(_id: string){
      return this.http.delete(this.baseURL + `/${_id}`);
    }
}
