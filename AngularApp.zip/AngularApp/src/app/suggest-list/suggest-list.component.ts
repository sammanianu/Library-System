import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { SuggestService } from '../shared/suggest.service';
import { Suggest } from '../shared/suggest.model';

declare var M: any;

@Component({
  selector: 'app-suggest-list',
  templateUrl: './suggest-list.component.html',
  styleUrls: ['./suggest-list.component.css'],
  providers: [SuggestService]
})
export class SuggestListComponent implements OnInit {

  constructor(private suggestService: SuggestService) { }

  ngOnInit() {
  	this.resetForm();
  	this.refreshSuggestList();
  }

  resetForm(form?: NgForm){
	  if(form)
  		form.reset();
  	this.suggestService.selectedSuggest = {
  		_id: "",
  		title: "",
  		author: ""
  	}
  }

  onSubmit(form:NgForm){
	if(form.value._id  ==""){
		this.suggestService.postSuggest(form.value).subscribe((res) => {
			this.resetForm(form);
			this.refreshSuggestList();
			M.toast({html: 'Saved successfully', classes: 'rounded'});
		});
	}
	else{
		this.suggestService.putSuggest(form.value).subscribe((res) => {
			this.resetForm(form);
			this.refreshSuggestList();
			M.toast({html: 'Updated successfully', classes: 'rounded'});
		});
	}
  }

  refreshSuggestList(){
  	this.suggestService.getSuggestList().subscribe((res) =>{
  		this.suggestService.suggests = res as Suggest[];
  	});
  }

  onEdit(sug: Suggest){
	this.suggestService.selectedSuggest = sug;
  }

  onDelete(_id: string, form: NgForm){
	  if (confirm('Are you sure to delete this record?') == true){
		this.suggestService.deleteSuggest(_id).subscribe((res) => {
			this.refreshSuggestList();
			this.resetForm(form);
			M.toast({ html: 'Deleted successfully', classes:'rounded'});
		});
	  }
  }
}





















